﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribution_Management_System
{
    public partial class UserDashboard : Form
    {
        public UserDashboard()
        {
            InitializeComponent();
            SidePanel.Height = btnHome.Height;
            SidePanel.Top = btnHome.Top;
            //adone1.BringToFront();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SidePanel.Height = btnOrder.Height;
            SidePanel.Top = btnOrder.Top;
            //adverttwo1.BringToFront();




        }

        private void button5_Click(object sender, EventArgs e)
        {
            SidePanel.Height = btnAbout.Height;
            SidePanel.Top = btnAbout.Top;
           // about1.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SidePanel.Height = btnStatus.Height;
            SidePanel.Top = btnStatus.Top;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SidePanel.Height = btnHome.Height;
            SidePanel.Top = btnHome.Top;
            //adone1.BringToFront();
          /*  if (btnHome.Enabled)
            {
                btnHome.BackColor = Color.FromArgb(225, 128, 0);
                btnHome.ForeColor = Color.White;
            }

*/
        }

        private void UserDashboard_Load(object sender, EventArgs e)
        {

        }

        private void adverttwo1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            DialogResult exit = MessageBox.Show("Would you like to proceed?", "LOG OUT", MessageBoxButtons.YesNo);

            if (exit == DialogResult.Yes)
            {
                new frmLogIn().Show();
                this.Hide();
            }
        }
    }
}
