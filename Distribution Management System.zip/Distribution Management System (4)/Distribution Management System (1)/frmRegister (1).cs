﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Distribution_Management_System
{
    public partial class frmRegister : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\db_users.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        public frmRegister()
        {
            InitializeComponent();
            
        }

        private void frmRegister_Load(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {

         

            if (txtUsername.Text == "" || txtPassword.Text == "" || txtComfirmPass.Text == "")
            {
                MessageBox.Show("Registration Failed!", "YOU CANNOT REGISTER EMPTY FIELDS", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtComfirmPass.Text = "";
                txtUsername.Focus();
            }

            else if (txtPassword.Text == txtComfirmPass.Text)
            {
                conn.Open();
                string checkUserQuery = "SELECT COUNT(*) FROM tbl_users WHERE username = @Username and password = @Password";
                SqlCommand checkUserCmd = new SqlCommand(checkUserQuery, conn);
                checkUserCmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                checkUserCmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                int userCount = (int)checkUserCmd.ExecuteScalar();
                conn.Close();

                if (userCount > 0)
                {
                    MessageBox.Show("Account Already Exists", "REGISTRATION FAILED");
                    txtUsername.Text = "";
                    txtPassword.Text = "";
                    txtComfirmPass.Text = "";
                    txtUsername.Focus();
                }
                
                else
                {
                    conn.Open();
                    string register = "INSERT INTO tbl_users VALUES('" + txtUsername.Text + "','" + txtPassword.Text + "')";
                    cmd = new SqlCommand(register, conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Your Account has been successfully created", "REGISTRATION SUCCESSFUL", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtUsername.Text = "";
                    txtPassword.Text = "";
                    txtComfirmPass.Text = "";
                }
               
            }
            else
            {
                MessageBox.Show("Password does not match, Please Re-enter your password", "REGISTRATION FAILED", MessageBoxButtons.OK,MessageBoxIcon.Error );
                txtPassword.Text = "";
                txtComfirmPass.Text = "";
                txtPassword.Focus();
            }
        }
        


        private void checkBoxShow_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShow.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtComfirmPass.PasswordChar = '\0';

            }
            else
            {
                txtPassword.PasswordChar = '*';
                txtComfirmPass.PasswordChar = '*';
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new frmLogIn().Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
