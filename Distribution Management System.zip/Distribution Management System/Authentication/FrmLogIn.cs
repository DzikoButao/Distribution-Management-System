﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace Authentication
{
    public partial class FrmLogIn : Form
    {
        public FrmLogIn()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();


        private void cmdExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            new frmRegister().Show();
            this.Hide();
        }

        private void checkBoxShowHide_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowHide.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string password = txtPassword.Text;
            string hashedPassword = HashPassword(password);

            if (txtUsername.Text == "ADMIN" && txtPassword.Text == "ROOT")
            {
                MessageBox.Show("WELCOME ADMIN");
                new FrmAdmin().Show();
                this.Hide();
            }
            else if (txtUsername.Text == "DISTRIBUTOR" && txtPassword.Text == "ROOT")
            {
                MessageBox.Show("WELCOME DISTRIBUTOR");
                new FrmDistributorLogIn().Show();
                this.Hide();
            }
            else
            {
                conn.Open();
                string login = "SELECT * FROM users WHERE username = '" + txtUsername.Text + "'AND password ='" + hashedPassword + "'";
                cmd = new SqlCommand(login, conn);
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read() == true)
                {
                    new FrmCustomer().Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid username or password ", "LOG IN FAILED", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
            conn.Close();
        }
        private static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();

                foreach (byte b in hashBytes)
                {
                    builder.Append(b.ToString("x2"));
                }

                return builder.ToString();
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
