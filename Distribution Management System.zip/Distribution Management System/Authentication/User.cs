﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication
{
    class User
    {
        private int id;

        public int ID
        {
            set { id = value; }
            get { return id; }
        }
        public string Username { set; get; }
        public string Password { set; get; }
    }
}
