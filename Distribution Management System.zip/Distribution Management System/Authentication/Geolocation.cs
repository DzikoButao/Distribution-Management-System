﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using System.Data.SqlClient;


namespace Authentication
{
    public partial class Geolocation : Form
    {
        string location;
        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();

        public Geolocation()
        {
            InitializeComponent();

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new FrmCustomer().Show();
            this.Hide();
        }

        private void Geolocation_Load(object sender, EventArgs e)
        {
            InitBrowser();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string location = LblAddress.Text;
            Location point = new Location();

            point.Customer_Address = location;


            if (location != "Address")
            {

                conn.Open();
                SqlCommand query = new SqlCommand("UPDATE orders SET [CUSTOMER ADDRESS] = '"+ LblAddress.Text + "' WHERE [CUSTOMER ADDRESS] IS NULL",conn);
                query.ExecuteNonQuery();
                MessageBox.Show("Order SuccessFul");
                conn.Close();
               
                new FrmCustomer().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please pin your location on the map");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
          
        }
        public async Task InitWebView()
        {
            await webView21.EnsureCoreWebView2Async(null);
        }
        public async void InitBrowser()
        {
            await InitWebView();
            webView21.CoreWebView2.Navigate("https://www.google.com/maps/@latitude,longitude");
        }

        private void ExtractAddressFromUrl(string url)
        {
            try
            {
                if (url.Contains("/place/"))
                {
                    int startIndex = url.LastIndexOf("/place/") + 7;
                    int endIndex = url.IndexOf("/", startIndex);
                    string locationWithPlus = url.Substring(startIndex, endIndex - startIndex);


                    string location = locationWithPlus.Replace("+", " ");
                    //string shortenedUrl = url.Length > 50 ? url.Substring(0, 50) + "..." : url;
                    LblAddress.Text = location;
                }
                else if (url.Contains("@"))
                {
                    string[] parts = url.Split('@')[1].Split(',');

                    if (parts.Length >= 2)
                    {
                        LblLatitude.Text = parts[0];
                        LblLongitude.Text = parts[1];
                    }
                }
                else
                {
                    MessageBox.Show("Invalid URL format.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while parsing the URL: " + ex.Message);
            }
        }

        private void webView21_SourceChanged(object sender, CoreWebView2SourceChangedEventArgs e)
        {
            string url = webView21.Source.ToString();
            ExtractAddressFromUrl(url);
        }

        private void LblAddress_Click(object sender, EventArgs e)
        {

        }
    }
}
