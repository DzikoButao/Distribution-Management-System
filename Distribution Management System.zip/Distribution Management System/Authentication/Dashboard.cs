﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Authentication
{
    public partial class Dashboard : Form
    {
         int count = 0;
        float itemcost = 0;
        string SelectedValue;

        DataGridViewTextBoxCell Itemname = new DataGridViewTextBoxCell();
        DataGridViewTextBoxCell quantity = new DataGridViewTextBoxCell();
        DataGridViewTextBoxCell cost = new DataGridViewTextBoxCell();

        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();

        public Dashboard()
        {
            InitializeComponent();

            PanelPage.Height = BtnMenu.Height;
            PanelPage.Top = BtnMenu.Top;
            brown_Bread1.BringToFront();
            ComboBoxFoodItems.Text = "Brown Bread";
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnLogOut_Click(object sender, EventArgs e)
        {
            new FrmLogIn().Show();
            this.Hide();
        }

        private void BtnMenu_Click(object sender, EventArgs e)
        {
            PanelPage.Height = BtnMenu.Height;
            PanelPage.Top = BtnMenu.Top;

            Pages.SetPage(((Control)sender).Text);
        }

        private void BtnOrders_Click(object sender, EventArgs e)
        {
           
            

        }

        private void BtnAbout_Click(object sender, EventArgs e)
        {
            
        }

        private void BtnOrders_Click_1(object sender, EventArgs e)
        {
            PanelPage.Height = BtnOrders.Height;
            PanelPage.Top = BtnOrders.Top;
            Pages.SetPage(((Control)sender).Text);
           
            
            
            conn.Open();
            DataTable dt = new DataTable();
            string query = "SELECT order_date, item, quantity, price, total_cost FROM orders";
            da = new SqlDataAdapter(query, conn);
            da.Fill(dt);
            dataGridViewCart.DataSource = da;
            conn.Close();
        }

        private void BtnAbout_Click_1(object sender, EventArgs e)
        {
            PanelPage.Height = BtnAbout.Height;
            PanelPage.Top = BtnAbout.Top;
            Pages.SetPage(((Control)sender).Text);

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
          
        }

        private void BtnPlus_Click(object sender, EventArgs e)
        {
            count++;
            LblQuantity.Text = "" + count;

            if(count >= 20)
            {
                count = 20;
                LblQuantity.Text = "" + count;
                MessageBox.Show("You have reached the maximum number of this product you are allowed to order");
            }

        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            count--;
            LblQuantity.Text = "" + count;
            if(count <= 0)
            {
                count = 0;
                LblQuantity.Text = "" + 0;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void bunifuPictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void DataGridQuotation_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        
        private void button16_Click(object sender, EventArgs e)
        {
            
        }
      
        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button22_Click(object sender, EventArgs e)
        {

        }

        private void button25_Click(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void bunifuPictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void bunifuPictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void bunifuPictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void BtnBuy_Click(object sender, EventArgs e)
        {
            
            
        }

        private void BtnPlus_Click_1(object sender, EventArgs e)
        {
            count++;
            LblQuantity.Text = "" + count;

            if(count > 20)
            {
                count = 20;
                LblQuantity.Text = "" + 20;
            }
        }

        private void BtnMinus_Click_1(object sender, EventArgs e)
        {
            count--;
            LblQuantity.Text = "" + count;

            if(count <= 0)
            {
                count = 0;
                LblQuantity.Text = "" + count;
            }
        }

        private void BtnBuy_Click_1(object sender, EventArgs e)
        {
             DataGridViewRow newRow = new DataGridViewRow();

            if (ComboBoxFoodItems.Text == "" || LblQuantity.Text == "" + 0)
            {
                MessageBox.Show("Food item or quantity is missing", "CANNOT IMPLICITLY PLACE YOUR ORDER IN CART");
            }
            else
            {
                
                    Itemname = new DataGridViewTextBoxCell();
                    Itemname.Value = ComboBoxFoodItems.Text;
                    newRow.Cells.Add(Itemname);
                


                quantity = new DataGridViewTextBoxCell();
                quantity.Value = LblQuantity.Text;
                newRow.Cells.Add(quantity);

                float itemtotal = itemcost * count;

                cost = new DataGridViewTextBoxCell();
                cost.Value = itemtotal;
                newRow.Cells.Add(cost);

                DataGridQuotation.Rows.Add(newRow);

                
            }
            

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void ComboBoxFoodItems_SelectedIndexChanged(object sender, EventArgs e)
        {

           SelectedValue = ComboBoxFoodItems.SelectedItem.ToString();
            
            if(SelectedValue == "Brown Bread")
            {
                itemcost = 1250;
                brown_Bread1.BringToFront();
                
            }
            else if (SelectedValue == "White Bread")
            {
                itemcost = 1250;
                white_Bread1.BringToFront();
               
            }
            else if(SelectedValue == "Donut")
            {
                itemcost = 150;
                donut1.BringToFront();
             
            }
            else if(SelectedValue == "Cream Donut")
            {
                itemcost =  250;
                cream_Donut1.BringToFront();
                
            }
            else if(SelectedValue == "Scone")
            {
                itemcost = 200;
                scone1.BringToFront();
                
            }
            else if(SelectedValue == "Cake")
            {
                itemcost =  12000;
                cake1.BringToFront();
                
            }
            else if(SelectedValue == "Cup Cake")
            {
                itemcost = 250;
                cup_Cake1.BringToFront();
                
            }
            else if (SelectedValue == "Bun")
            {
                itemcost = 250;
                bun1.BringToFront();
               
            }
            else if(SelectedValue == "Potato Samoosa")
            {
                itemcost = 150;
                potato_Samoosa1.BringToFront();
               
            }
            else if(SelectedValue == "Beef Samoosa")
            {
                itemcost = 250;
                beef_Samoosa1.BringToFront();
                ComboBoxFoodItems.Text = "";
                LblQuantity.Text = "" + 0;
            }
            else if(SelectedValue == "Bread Roll")
            {
                itemcost = 350;
                bread_Roll1.BringToFront();
                
            }
            else if(SelectedValue == "Meat Pie")
            {
                itemcost = 1200;
                meat_Pie1.BringToFront();
                
            }
            count = 0;
            LblQuantity.Text = "" + count;

        }

        private void button35_Click(object sender, EventArgs e)
        {
           
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            DataGridQuotation.Rows.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (DataGridQuotation.RowCount == 0)
            {
                MessageBox.Show("You do not have any orders", "ORDER PLACEMENT FAILURE", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                
                    conn.Open();
                    string insert = "INSERT INTO orders (item, Quantity, Price, Total_Cost) VALUES ('"+ Itemname.Value +"', '" + quantity.Value  + "', '" + itemcost + "', '" + cost.Value + "')";
                    cmd = new SqlCommand(insert, conn);
                    cmd.Parameters.AddWithValue("@Itemname", Itemname.Value);
                    cmd.Parameters.AddWithValue("@quantity", quantity.Value);
                    cmd.Parameters.AddWithValue("@itemcost", itemcost);
                    cmd.Parameters.AddWithValue("@cost", cost.Value);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                

                new Geolocation().Show();
                this.Hide();
            }
        }

        private void PanelMenuBar_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    
}
