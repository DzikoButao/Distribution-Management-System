﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Authentication
{
    public partial class Potato_Samoosa : UserControl
    {
        public Potato_Samoosa()
        {
            InitializeComponent();
        }
    }
}
