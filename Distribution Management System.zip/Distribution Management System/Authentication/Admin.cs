﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication
{
    class Admin : User
    {
        private int id;
        private string username;
        private string password;


       
        public int ID
        {
            set { id = value; }
            get { return id; }
        }
        public string Username
        {
            set { username = value; }
            get { return username; }
        }
        public string Password
        {
            set { password = value; }
            get { return password; }
        }
        
    }
}
