﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication
{
    class Product
    {
        private int product_id;
        private string product_name;
        private float product_price;
        private int product_quantity;

        public int ProductID
        {
            set { product_id = value; }
            get { return product_id; }
        }
        public string ProductName
        {
            set { product_name = value; }
            get { return product_name; }
        }
        public float ProductPrice
        {
            set { product_price = value; }
            get { return product_price; }
        }
        public int ProductQuantity
        {
            set { product_quantity = value; }
            get { return product_quantity; }
        }
    }
}
