﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication
{
    class Distributor : User
    {
        private int Distributor_id;
        private string username;
        private string password;
    }
}
