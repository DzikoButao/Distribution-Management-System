﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace Authentication
{
    public partial class FrmDistributor : Form
    {
        public FrmDistributor()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();

        private void button5_Click(object sender, EventArgs e)
        {
            new FrmDistributorLogIn().Show();
            this.Hide();
        }

        private void BtnMenu_Click(object sender, EventArgs e)
        {
            PanelPage.Height = BtnOrders.Height;
            PanelPage.Top = BtnOrders.Top;
            bunifuPages.SetPage(((Control)sender).Text);

          


            conn.Open();
            SqlCommand query = new SqlCommand("SELECT Order_id, [ORDER DATE], ITEM, QUANTITY, PRICE, [COST],[ORDER STATUS],[CUSTOMER ADDRESS] FROM orders ORDER BY [ORDER DATE] DESC", conn);
            da = new SqlDataAdapter(query);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewCart.DataSource = dt;
            conn.Close();
        }

        private void BtnMessage_Click(object sender, EventArgs e)
        {
        }

        private void BtnAbout_Click(object sender, EventArgs e)
        {
            PanelPage.Height = BtnReport.Height;
            PanelPage.Top = BtnReport.Top;

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV Files (*.csv)|*.csv";
            saveFileDialog.Title = "Save Quotation to CSV File";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string csvFilePath = saveFileDialog.FileName;

                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security=True;Connect Timeout=30";
                string sqlQuery = "SELECT * from orders";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);
                            GenerateReport(dataTable, csvFilePath);
                            MessageBox.Show("CSV report generated successfully.");
                        }
                    }
                }
            }
        }
        


        static void GenerateReport(DataTable data, string filePath)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (DataColumn column in data.Columns)
                    {
                        writer.Write(column.ColumnName);
                        if (column != data.Columns[data.Columns.Count - 1])
                        {
                            writer.Write(",");
                        }
                    }
                    writer.WriteLine();

                    foreach (DataRow row in data.Rows)
                    {
                        for (int i = 0; i < data.Columns.Count; i++)
                        {
                            writer.Write(row[i]);
                            if (i != data.Columns.Count - 1)
                            {
                                writer.Write(",");
                            }
                        }
                        writer.WriteLine();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }


        private void comboBoxStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

            string selectedStatus = comboBoxStatus.SelectedItem.ToString();

            using (SqlConnection connection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security = True; Connect Timeout = 30"))
            {
                conn.Open();

                string updateSql = $"UPDATE orders SET [ORDER STATUS] = '{selectedStatus}'";
                SqlCommand command = new SqlCommand(updateSql, conn);
                command.ExecuteNonQuery();
                dataGridViewCart.ReadOnly = false;
              
                try
                {
                    string accountSid = "AC4ec18ae5a2e1f44659161bdb598a1376";
                    string authToken = "bd6af5066b52c25dfe6817c2bdebf7d9";
                    TwilioClient.Init(accountSid, authToken);
                    var toPhoneNumber = new PhoneNumber("+265881836268");
                    var fromPhoneNumber = new PhoneNumber("+12565488510");
                    string messageText = $"Dear Customer, this is Laher Bakery. We would like to inform you that your order is '{selectedStatus}'.";
                    var message = MessageResource.Create(
                        to: toPhoneNumber,
                        from: fromPhoneNumber,
                        body: messageText
                    );
                    MessageBox.Show($"SMS sent with SID: {message.Sid}");
                }
                catch
                {
                    MessageBox.Show("Internet Connection Error. Please make sure you have an established internet connection");
                }

                dataGridViewCart.Refresh();
                conn.Close();
            }


        }

        private void btnMessage_Click_1(object sender, EventArgs e)
        {     
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

           
        }
    }
}
