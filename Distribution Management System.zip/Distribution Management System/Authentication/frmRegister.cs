﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Security.Cryptography;

namespace Authentication
{
    public partial class frmRegister : Form
    {
        public frmRegister()
        {
            InitializeComponent();
        }
       
        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();

        private void label2_Click(object sender, EventArgs e)
        {
            new FrmLogIn().Show();
            this.Hide();
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void checkBoxShowHide_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowHide.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtComfirmPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
                txtComfirmPassword.PasswordChar = '*';
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            User user = new User();

            user.Username = txtUsername.Text;
            user.Password = txtPassword.Text;

            if (txtUsername.Text == "" || txtPassword.Text == "" || txtComfirmPassword.Text == "")
            {
                MessageBox.Show("YOU CANNOT HAVE EMPTY FIELDS", "REGISTRATION FAILED", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtComfirmPassword.Text = "";
                txtUsername.Focus();
            }
           
          
            if(txtPassword.Text == txtComfirmPassword.Text)
            {
                string password = txtPassword.Text;
                bool PasswordValid = IsPasswordValid(password);
                string hashedPassword = HashPassword(password);

               

                if (txtPassword.Text.Length >= 8)
                {
                  

                    if (PasswordValid)
                    {
                        conn.Open();
                        string checkUserQuery = "SELECT COUNT(*) FROM users WHERE password = @Password";
                        SqlCommand checkUserCmd = new SqlCommand(checkUserQuery, conn);
                        checkUserCmd.Parameters.AddWithValue("@Password", hashedPassword);
                        int userCount = (int)checkUserCmd.ExecuteScalar();
                        conn.Close();

                        if (userCount > 0)
                        {
                            MessageBox.Show("Password is already in use. Two users cannot share the same password", "REGISTATION FAILED");
                            txtPassword.Text = "";
                            txtComfirmPassword.Text = "";
                            txtPassword.Focus();

                        }
                       
                        else
                        {
                            if (ContainsUppercaseLowercase(password))
                            {
                                conn.Open();
                                string register = "INSERT INTO users VALUES('" + txtUsername.Text + "', '" + hashedPassword + "')";
                                cmd = new SqlCommand(register, conn);
                                cmd.ExecuteNonQuery();
                                conn.Close();
                                MessageBox.Show("Account Created Successfully", "REGISTRATION COMPLETE");
                                txtUsername.Text = "";
                                txtPassword.Text = "";
                                txtComfirmPassword.Text = "";
                                txtUsername.Focus();
                            }
                            else
                            {
                                MessageBox.Show("Insecure Password. It must contain atleast 8 characters and must contain a combination of uppercase and lowercase letters, numbers and symbols", "REGISTRATION FAILED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                txtPassword.Text = "";
                                txtComfirmPassword.Text = "";
                                txtPassword.Focus();
                            }
                        }
                    }

                    else
                    {
                        MessageBox.Show("Insecure Password. It must contain atleast 8 characters and must contain a combination of uppercase and lowercase letters, numbers and symbols", "REGISTRATION FAILED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtPassword.Text = "";
                        txtComfirmPassword.Text = "";
                        txtUsername.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Insecure Password. It must contain atleast 8 characters and must contain a combination of uppercase and lowercase letters, numbers and symbols", "REGISTRATION FAILED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtPassword.Text = "";
                    txtComfirmPassword.Text = "";
                    txtUsername.Focus();
                }

            }
            else
            {
                MessageBox.Show("Passwords do not match", "REGISTRATION FAILED", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Text = "";
                txtComfirmPassword.Text = "";
                txtPassword.Focus();
            }
        }
        private bool IsPasswordValid(string password)
        {
            string pattern = @"^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,}$";
            return Regex.IsMatch(password, pattern);
        }
        private bool ContainsUppercaseLowercase(string password)
        {
            bool uppercase = false;
            bool lowercase = false;

            foreach(char c in password)
            {
                if (char.IsUpper(c))
                {
                    uppercase = true;
                }
                if (char.IsLower(c))
                {
                    lowercase = true;
                }
                if(uppercase && lowercase)
                {
                    return true;
                }
            }
            return false;

        }
        private static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();

                foreach (byte b in hashBytes)
                {
                    builder.Append(b.ToString("x2")); 
                }

                return builder.ToString();
            }
        }

        private void frmRegister_Load(object sender, EventArgs e)
        {

        }
    }
}
