﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication
{
    class Customer : User
    {
        private int Customer_id;
        private string username;
        private string password;
    }
}
