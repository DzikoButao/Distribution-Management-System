﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Authentication
{
    public partial class FrmAdmin : Form
    {
        public FrmAdmin()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                cmd = new SqlCommand("INSERT INTO Distributors VALUES(@Username, @Password)", conn);
                cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Distributor Account Created Successfully");
                conn.Close();
            }
            catch
            {
                MessageBox.Show("Error, Cannot create account. username and password must be missing");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd = new SqlCommand("UPDATE Distributors SET username = @Username, password = @password WHERE Distributor_Id = @ID", conn);
            cmd.Parameters.AddWithValue("@ID", TxtID.Text);
            cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Account Updated Successfully");
            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd = new SqlCommand("DELETE Distributors WHERE Distributor_Id = @ID ", conn);
            cmd.Parameters.AddWithValue("@ID", TxtID.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Account Deleted");
            conn.Close();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
                conn.Open();
                cmd = new SqlCommand("SELECT * FROM Distributors WHERE username = @username ", conn);
                cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewDistributors.DataSource = dt;
                conn.Close();
          
        }

        private void BtnLogOut_Click(object sender, EventArgs e)
        {
            new FrmLogIn().Show();
            this.Hide();
        }
    }
}
