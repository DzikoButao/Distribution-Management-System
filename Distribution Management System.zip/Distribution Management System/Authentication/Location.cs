﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication
{
    class Location
    {
        private string customer_address;

        public string Customer_Address
        {
            set { customer_address = value; }
            get { return customer_address; }
        }
    }
}
