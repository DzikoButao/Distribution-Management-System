﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Authentication
{
    public partial class FrmDistributorLogIn : Form
    {
        public FrmDistributorLogIn()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Escom_users.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();

        private void cmdExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void checkBoxShowHide_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowHide.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            conn.Open();
            string login = "SELECT * FROM Distributors WHERE username = '" + txtUsername.Text + "'AND password ='" + txtPassword.Text + "'";
            cmd = new SqlCommand(login, conn);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read() == true)
            {
                new FrmDistributor().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid username or password ", "LOG IN FAILED", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new FrmLogIn().Show();
            this.Hide();
        }

        private void cmdExit_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
