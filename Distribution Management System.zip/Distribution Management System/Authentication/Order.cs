﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication
{
    class Order
    {
        private int order_id;
        private string product_id;
        private DateTime orderddate;
        
        public int Order_ID
        {
            set { order_id = value; }
            get { return order_id; }
        }
        public string Product_ID
        {
            set { product_id = value; }
            get { return product_id; }
        }

    }
}
